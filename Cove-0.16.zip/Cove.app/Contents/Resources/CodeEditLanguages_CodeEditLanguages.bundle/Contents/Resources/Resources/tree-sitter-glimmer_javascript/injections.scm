; Highlight the contents of a gjs/gts <template> tag with the Glimmer grammar.
((glimmer_template
  (raw_text) @injection.content)
 (#set! injection.language "glimmer"))

; One still open at the end of the file (typed top down, its `</template>` not there yet) is an ERROR holding its
; opening tag and the text after it: the same block, so Return and typing read it as Glimmer meanwhile. Through the
; ERROR's end, past a `<` or `</` the text stops short of.
((ERROR
  (glimmer_opening_tag) .
  (raw_text) @injection.content)
 (#set! injection.language "glimmer")
 (#set! injection.through-parent "true"))

; JSDoc annotations inside comments. Only `/**` block comments are JSDoc — not `//` line
; comments, plain `/* */`, or `/*** */` (per the JSDoc spec); the predicate gates on that.
((comment) @injection.content
 (#match? @injection.content "^/\\*\\*[^*]")
 (#set! injection.language "jsdoc"))

; Regex literals.
((regex_pattern) @injection.content
 (#set! injection.language "regex"))
