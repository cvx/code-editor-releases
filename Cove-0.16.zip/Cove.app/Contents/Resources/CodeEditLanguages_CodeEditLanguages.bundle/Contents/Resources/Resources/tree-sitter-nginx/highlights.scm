(comment) @comment

; A block's name is structure (`server {`, `location / {`); a statement's is a setting, colored like
; an INI or YAML key.
(directive
  name: (directive_name) @keyword
  body: (block))

(directive
  name: (directive_name) @property
  ";")

; `location`'s match modifier.
((directive
  name: (directive_name) @_name
  .
  (value) @operator)
  (#eq? @_name "location")
  (#any-of? @operator "=" "~" "~*" "^~"))

((value) @boolean
  (#any-of? @boolean "on" "off"))

; A count, size (`32k`) or time (`30s`, `1y`).
((value) @number
  (#match? @number "^[0-9]+([.][0-9]+)?(ms|[smhdwMykKgG])?$"))

(variable) @variable

(string) @string

(escape_sequence) @string.escape

";" @punctuation.delimiter

[
  "{"
  "}"
] @punctuation.bracket
