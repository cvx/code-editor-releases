; Glimmer JS (`.gjs`) locals — the plain JavaScript query, in this fork's node names
; (`function_expression`, not the blob grammar's `function`), so `#is-not? local` in highlights.scm
; can tell a local `window`/`require` from the global. Same scopes, definitions and references as
; tree-sitter-javascript/locals.scm.

; Scopes
;-------

[
  (statement_block)
  (function_expression)
  (arrow_function)
  (function_declaration)
  (method_definition)
] @local.scope

; Definitions
;------------

(pattern/identifier) @local.definition

(variable_declarator
  name: (identifier) @local.definition)

; References
;------------

(identifier) @local.reference
