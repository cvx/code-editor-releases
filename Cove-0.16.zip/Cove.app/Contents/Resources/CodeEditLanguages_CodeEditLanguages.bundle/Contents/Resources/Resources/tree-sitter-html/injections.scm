((script_element
  (raw_text) @injection.content)
 (#set! injection.language "javascript"))

((style_element
  (raw_text) @injection.content)
 (#set! injection.language "css"))

; A `lang` attribute picks the grammar over the plain patterns above (a Vue single-file component's
; `<script setup lang="ts">`, `<style scoped lang="scss">`), quoted or not. Priority, not match
; order, decides which of two patterns on one block wins.
((script_element
  (start_tag
    (attribute
      (attribute_name) @_attr
      [(quoted_attribute_value (attribute_value) @_lang) (attribute_value) @_lang]))
  (raw_text) @injection.content)
 (#eq? @_attr "lang")
 (#any-of? @_lang "ts" "typescript")
 (#set! injection.language "typescript")
 (#set! injection.priority "100"))

((script_element
  (start_tag
    (attribute
      (attribute_name) @_attr
      [(quoted_attribute_value (attribute_value) @_lang) (attribute_value) @_lang]))
  (raw_text) @injection.content)
 (#eq? @_attr "lang")
 (#eq? @_lang "tsx")
 (#set! injection.language "tsx")
 (#set! injection.priority "100"))

((style_element
  (start_tag
    (attribute
      (attribute_name) @_attr
      [(quoted_attribute_value (attribute_value) @_lang) (attribute_value) @_lang]))
  (raw_text) @injection.content)
 (#eq? @_attr "lang")
 (#any-of? @_lang "scss" "less")
 (#set! injection.language "scss")
 (#set! injection.priority "100"))

; A `<script>` or `<style>` still open at the end of the document (typed top down, its end tag not there yet) is an
; ERROR holding its start tag and the raw text after it: the same block, read in its own terms meanwhile, through the
; ERROR's end, past a `<` or `</` the text stops short of.
((ERROR
  (start_tag (tag_name) @_tag) .
  (raw_text) @injection.content)
 (#eq? @_tag "script")
 (#set! injection.language "javascript")
 (#set! injection.through-parent "true"))

((ERROR
  (start_tag (tag_name) @_tag) .
  (raw_text) @injection.content)
 (#eq? @_tag "style")
 (#set! injection.language "css")
 (#set! injection.through-parent "true"))

((ERROR
  (start_tag
    (tag_name) @_tag
    (attribute
      (attribute_name) @_attr
      [(quoted_attribute_value (attribute_value) @_lang) (attribute_value) @_lang])) .
  (raw_text) @injection.content)
 (#eq? @_tag "script")
 (#eq? @_attr "lang")
 (#any-of? @_lang "ts" "typescript")
 (#set! injection.language "typescript")
 (#set! injection.priority "100")
 (#set! injection.through-parent "true"))

((ERROR
  (start_tag
    (tag_name) @_tag
    (attribute
      (attribute_name) @_attr
      [(quoted_attribute_value (attribute_value) @_lang) (attribute_value) @_lang])) .
  (raw_text) @injection.content)
 (#eq? @_tag "script")
 (#eq? @_attr "lang")
 (#eq? @_lang "tsx")
 (#set! injection.language "tsx")
 (#set! injection.priority "100")
 (#set! injection.through-parent "true"))

((ERROR
  (start_tag
    (tag_name) @_tag
    (attribute
      (attribute_name) @_attr
      [(quoted_attribute_value (attribute_value) @_lang) (attribute_value) @_lang])) .
  (raw_text) @injection.content)
 (#eq? @_tag "style")
 (#eq? @_attr "lang")
 (#any-of? @_lang "scss" "less")
 (#set! injection.language "scss")
 (#set! injection.priority "100")
 (#set! injection.through-parent "true"))
