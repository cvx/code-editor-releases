(comment) @comment

; `Host` and `Match` open a section (keywords are case-insensitive); the rest are its settings,
; colored like an INI or YAML key. First, so it wins the same span over the line below.
((directive
  name: (keyword) @keyword)
  (#match? @keyword "^([Hh][Oo][Ss][Tt]|[Mm][Aa][Tt][Cc][Hh])$"))

(directive
  name: (keyword) @property)

((value) @boolean
  (#any-of? @boolean "yes" "no"))

; A port, count or time (`30s`, `1h30m`).
((value) @number
  (#match? @number "^[0-9]+([sSmMhHdDwW][0-9]*)*$"))

(string) @string

"=" @operator
