---
name: simplify
description: Quality-only review of the current diff for unnecessary complexity, duplication, and avoidable cost; do not hunt correctness bugs—use an available code-review workflow.
---

# Simplify

Review the current diff and improve it where doing so makes the result clearer, smaller, more reusable, or less expensive without changing the intended behavior. Quality only: do not look for correctness bugs; use an available code-review workflow for those.

When the invocation includes a `Review target:` block, review that explicit target. Otherwise, review the current diff. Do not expand the scope to recent commits or ask for an alternate scope.

When collaboration tools are available, dispatch four independent, read-only reviewers over the changed files and their nearby call sites:

- reuse: flag new code that re-implements something the codebase already has; search shared/utility modules and files adjacent to the change, and name the existing helper to call instead;
- simplification: flag unnecessary complexity the diff adds: redundant or derivable state, copy-paste with slight variation, deep nesting, needless indirection, dead code left behind; name the simpler form that does the same job;
- efficiency: flag wasted work the diff introduces: redundant computation or repeated I/O, independent operations run sequentially, blocking work added to startup or hot paths, long-lived closures that keep a large enclosing scope alive; name the cheaper alternative;
- altitude: check that each change fixes the root cause at the right depth rather than patching a symptom; special cases layered on shared infrastructure mean the fix isn't deep enough, so name the simpler, more general change to the underlying mechanism.

Brief each reviewer with its lens from the list above, the review target, and these rules:

- Read the whole diff and every function it touches, then look beyond it: the helpers, types and call sites around the change, and the shared or utility code it could have reused.
- Report every candidate considered, minor ones included. Do not judge whether a candidate is worth fixing; the parent decides that.
- Give each candidate the file, the line, a one-line summary, the concrete cost (what is duplicated, wasted, or harder to maintain) and the simpler alternative.
- Name what was searched: the commands run, and the helpers, symbols and call sites looked for. A report with no candidates shows this the same way.
- Do not edit files.

A spawn the session refuses for its agent cap is a queue, not unavailable collaboration: start the next reviewer as one finishes, and don't mention it.

If collaboration is unavailable, make one serial review using the same four lenses and rules, and state in the final summary that it was a single-pass review without parallel reviewers.

As the parent, collect every candidate, merge the ones that point at the same line or mechanism, and decide each on its merits. Fix the ones worth fixing. Reject a candidate that would change intended behavior, requires changes well outside the reviewed diff, is a false positive, or would replace a deliberate implementation that is already the clearest way to preserve an important invariant.

Finish with a brief summary: what was fixed, and every rejected candidate with the reason it was rejected. Report the code as already clean only when no candidate was worth fixing, and list the rejected candidates when you do.
