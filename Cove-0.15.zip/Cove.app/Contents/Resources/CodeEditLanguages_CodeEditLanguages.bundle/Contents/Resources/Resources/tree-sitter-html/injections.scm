((script_element
  (raw_text) @injection.content)
 (#set! injection.language "javascript"))

((style_element
  (raw_text) @injection.content)
 (#set! injection.language "css"))

; A `lang` attribute picks the grammar over the plain patterns above (a Vue single-file component's
; `<script setup lang="ts">`, `<style scoped lang="scss">`), quoted or not. Priority, not match
; order, decides which of two patterns on one block wins.
((script_element
  (start_tag
    (attribute
      (attribute_name) @_attr
      [(quoted_attribute_value (attribute_value) @_lang) (attribute_value) @_lang]))
  (raw_text) @injection.content)
 (#eq? @_attr "lang")
 (#any-of? @_lang "ts" "typescript")
 (#set! injection.language "typescript")
 (#set! injection.priority "100"))

((script_element
  (start_tag
    (attribute
      (attribute_name) @_attr
      [(quoted_attribute_value (attribute_value) @_lang) (attribute_value) @_lang]))
  (raw_text) @injection.content)
 (#eq? @_attr "lang")
 (#eq? @_lang "tsx")
 (#set! injection.language "tsx")
 (#set! injection.priority "100"))

((style_element
  (start_tag
    (attribute
      (attribute_name) @_attr
      [(quoted_attribute_value (attribute_value) @_lang) (attribute_value) @_lang]))
  (raw_text) @injection.content)
 (#eq? @_attr "lang")
 (#any-of? @_lang "scss" "less")
 (#set! injection.language "scss")
 (#set! injection.priority "100"))
