; Recipe lines are shell — sub-highlight them with bash. The make expansions inside (`$(CC)`, `$@`)
; are masked before the bash sub-parse (see TreeSitterHighlighter), so the make grammar's own coloring
; of them survives and bash only colors the surrounding shell.
((shell_text) @injection.content
 (#set! injection.language "bash"))
