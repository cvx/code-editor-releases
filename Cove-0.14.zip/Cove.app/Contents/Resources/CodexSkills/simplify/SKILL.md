---
name: simplify
description: Quality-only review of the current diff for unnecessary complexity, duplication, and avoidable cost; do not hunt correctness bugs—use an available code-review workflow.
---

# Simplify

Review the current diff and improve it where doing so makes the result clearer, smaller, more reusable, or less expensive without changing the intended behavior. Quality only: do not look for correctness bugs; use an available code-review workflow for those.

When the invocation includes a `Review target:` block, review that explicit target. Otherwise, review
the current diff. Do not expand the scope to recent commits or ask for an alternate scope.

When collaboration tools are available, dispatch four independent, read-only reviewers in parallel over
the changed files and their nearby call sites:

- reuse: find existing utilities, patterns, or abstractions the change should use;
- simplification: find duplicated logic, needless state, indirection, or overly broad interfaces;
- efficiency: find avoidable work, especially on likely hot paths;
- altitude: assess whether the design belongs at the right layer and preserves important invariants.

Give each reviewer a narrow brief and have it return findings without editing, each one carrying the
file, the line, a one-line summary, and the concrete cost: what is duplicated, wasted, or harder to
maintain. If collaboration is unavailable, make one serial review using the same four lenses and state
in the final summary that it was a single-pass review without the Agent tool.

Deduplicate findings that point at the same line or mechanism and make only worthwhile fixes. Skip a
proposed fix if it would change intended behavior, requires changes well outside the reviewed diff, or
is a false positive; note the skip rather than arguing with it. Keep a deliberate implementation when it
is already the clearest way to preserve an important invariant. Finish with a brief summary of what was
fixed, what was skipped and any remaining tradeoffs, or confirm the code was already clean.
