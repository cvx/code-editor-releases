(comment_directive) @comment

; ERB directive markers are the Ruby-embedding boundary — same accent as other interpolations.
[
  "<%#"
  "<%"
  "<%="
  "<%_"
  "<%-"
  "%>"
  "-%>"
  "_%>"
] @punctuation.special
