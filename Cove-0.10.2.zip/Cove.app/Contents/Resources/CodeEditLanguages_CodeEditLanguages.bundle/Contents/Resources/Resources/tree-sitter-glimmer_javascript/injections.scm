; Highlight the contents of a gjs/gts <template> tag with the Glimmer grammar.
((glimmer_template
  (raw_text) @injection.content)
 (#set! injection.language "glimmer"))

; JSDoc annotations inside comments. Only `/**` block comments are JSDoc — not `//` line
; comments, plain `/* */`, or `/*** */` (per the JSDoc spec); the predicate gates on that.
((comment) @injection.content
 (#match? @injection.content "^/\\*\\*[^*]")
 (#set! injection.language "jsdoc"))

; Regex literals.
((regex_pattern) @injection.content
 (#set! injection.language "regex"))
