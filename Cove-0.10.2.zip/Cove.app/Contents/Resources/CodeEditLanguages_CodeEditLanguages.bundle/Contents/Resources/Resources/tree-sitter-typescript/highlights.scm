; Types

(type_identifier) @type
(predefined_type) @type.builtin

; Value-position identifiers are left to the parent `javascript` query so TS colors them exactly
; like JS (NaN/Infinity → constant.builtin, SCREAMING → constant, JSON → constructor, other
; Capitalized → constructor). A blanket `((identifier) @type (#match "^[A-Z]"))` here used to
; override all of that, mis-coloring NaN/SCREAMING_CASE as @type. Type *positions* are still
; `(type_identifier)` above.

(type_arguments
  "<" @punctuation.bracket
  ">" @punctuation.bracket)

; Variables

(required_parameter (identifier) @variable.parameter)
(optional_parameter (identifier) @variable.parameter)

; Keywords

[ "abstract"
  "declare"
  "enum"
  "export"
  "implements"
  "interface"
  "keyof"
  "namespace"
  "private"
  "protected"
  "public"
  "type"
  "readonly"
  "override"
  "satisfies"
] @keyword
