
; Tags that start with a capital letter are components
((tag_name) @constructor
  (#match? @constructor "^[A-Z]"))

; === Tag Names ===
; Tags that start with a lower case letter are HTML tags
; We'll also use this highlighting for named blocks (which start with `:`)
((tag_name) @tag
  (#match? @tag "^:?[a-z]"))

; Component arguments (`@name`) get their own color, distinct from plain HTML attributes below.
((attribute_name) @property
  (#match? @property "^@"))

(attribute_name) @variable

(string_literal) @string

(number_literal) @number

(boolean_literal) @boolean

(concat_statement) @string

; === Block Statements ===
; Highlight `if`/`each`/`let` FIRST so the helper keyword wins over the whole-statement
; @punctuation.special below (first-match-wins) — otherwise `{{#if}}`'s `if` takes the bracket accent.
(block_statement_start
  path: (identifier) @keyword)

(block_statement_end
  path: (identifier) @keyword)

((block_statement_start
  (identifier) @keyword.conditional)
  (#eq? @keyword.conditional "if"))

((block_statement_end
  (identifier) @keyword.conditional)
  (#eq? @keyword.conditional "if"))

((mustache_statement
  (identifier) @keyword.conditional)
  (#eq? @keyword.conditional "else"))

; Brackets/separators of the whole statement — the embedding-boundary accent. Children captured
; above (keywords, paths) override the inner content; only the `{{ }}`/`{{# /}}` markers remain.
(block_statement_start) @punctuation.special
(block_statement_end) @punctuation.special
(mustache_statement) @punctuation.special

; A method-style path in helper position (`{{this.save x}}`) — the invoked last segment is a
; method call, like JS `this.save(x)`. (Before the generic path rules so it wins on that segment.)
(helper_invocation
  helper: (path_expression (identifier) @function.method .))

; Path access mirrors JS member access: the leading segment is a variable (or `this`), and the
; trailing segments after a `.` are properties — so `{{this.count}}` colors `count` like JS does.
((identifier) @variable.builtin
  (#eq? @variable.builtin "this"))

(path_expression . (identifier) @variable)
(path_expression (identifier) @property)

; An identifier in a mustache expression is a variable
((mustache_statement
  [
    (path_expression
      (identifier) @variable)
    (identifier) @variable
  ])
  (#not-any-of? @variable "yield" "outlet" "this" "else"))

; As are arguments in a block statement
(block_statement_start
  argument: [
    (path_expression
      (identifier) @variable)
    (identifier) @variable
  ])

; As is an identifier in a block param
(block_params
  (identifier) @variable)

; As are helper arguments
((helper_invocation
  argument: [
    (path_expression
      (identifier) @variable)
    (identifier) @variable
  ])
  (#not-eq? @variable "this"))

; `this` should be highlighted as a built-in variable
((identifier) @variable.builtin
  (#eq? @variable.builtin "this"))

; If the identifier is just "yield" or "outlet", it's a keyword
((mustache_statement
  (identifier) @keyword)
  (#any-of? @keyword "yield" "outlet"))

; Helpers are functions
((helper_invocation
  helper: [
    (path_expression
      (identifier) @function)
    (identifier) @function
  ])
  (#not-any-of? @function "if" "yield"))

((helper_invocation
  helper: (identifier) @keyword.conditional)
  (#eq? @keyword.conditional "if"))

((helper_invocation
  helper: (identifier) @keyword)
  (#eq? @keyword "yield"))

(hash_pair
  key: (identifier) @property)

(comment_statement) @comment

(attribute_node
  "=" @operator)

(block_params
  "as" @keyword)

(block_params
  "|" @operator)

[
  "<"
  ">"
  "</"
  "/>"
] @punctuation.bracket

; Sub-expression parens (`{{capitalize (concat …)}}`) are neutral brackets like a JS call's `()`,
; not the `{{ }}` embedding accent they'd otherwise inherit from the enclosing mustache_statement.
(sub_expression ["(" ")"] @punctuation.bracket)
