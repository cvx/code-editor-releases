; Recipe lines are shell — sub-highlight them with bash. The make expansions inside (`$(CC)`, `$@`)
; are masked before the bash sub-parse (see TreeSitterHighlighter), so the make grammar's own coloring
; of them survives and bash only colors the surrounding shell.
((shell_text) @injection.content
 (#set! injection.language "bash"))

; A `define … endef` body (a canned recipe) is shell too, but the grammar keeps it as one opaque
; `raw_text` node — so make tokenizes nothing inside it, not even the expansions. Bash colors the
; shell here; `TreeSitterHighlighter.highlightMakeDefineExpansions` re-adds the make coloring the
; masked expansions would otherwise lose.
((raw_text) @injection.content
 (#set! injection.language "bash"))
