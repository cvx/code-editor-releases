; tree-sitter-javascript highlights (matches the glimmer_javascript grammar's JS base),
; plus the Glimmer <template> tag captures. Self-contained — NOT combined with the
; blob's javascript query, which targets an older grammar (function vs function_expression).

; Function and method definitions
;--------------------------------

(function_expression
  name: (identifier) @function)
(function_declaration
  name: (identifier) @function)
(method_definition
  name: (property_identifier) @function.method)
(method_definition
  name: (private_property_identifier) @function.method) ; `#m() {}`

(pair
  key: (property_identifier) @function.method
  value: [(function_expression) (arrow_function)])

(assignment_expression
  left: (member_expression
    property: (property_identifier) @function.method)
  right: [(function_expression) (arrow_function)])

(variable_declarator
  name: (identifier) @function
  value: [(function_expression) (arrow_function)])

(assignment_expression
  left: (identifier) @function
  right: [(function_expression) (arrow_function)])

; Function and method calls
;--------------------------

(call_expression
  function: (identifier) @function)

(call_expression
  function: (member_expression
    property: (property_identifier) @function.method))
(call_expression
  function: (member_expression
    property: (private_property_identifier) @function.method)) ; `this.#m()`

; Decorators (`@tracked`, `@service(…)`) — color the `@` and name like a function, before the
; (identifier) catch-all below so the bare-decorator name wins over @variable.
(decorator "@" @function)
(decorator (identifier) @function)

; Special identifiers
;--------------------
; Order matters (first-match-wins): value globals, then all-caps builtin objects, then
; SCREAMING_CASE constants, then the bare Capitalized→constructor catch-all. Kept identical to
; the plain `javascript` query so `.gjs` and `.js` color these the same (e.g. FOO → @constant).

; Value globals (NaN/Infinity) are numeric constants, not types — like true/false/null.
((identifier) @constant.builtin
 (#any-of? @constant.builtin "NaN" "Infinity"))

; All-caps builtin OBJECTS (JSON) are like Math, not SCREAMING_CASE user constants.
((identifier) @constructor
 (#any-of? @constructor "JSON"))

([
    (identifier)
    (shorthand_property_identifier)
    (shorthand_property_identifier_pattern)
 ] @constant
 (#match? @constant "^[A-Z_][A-Z\\d_]+$"))

((identifier) @constructor
 (#match? @constructor "^[A-Z]"))

((identifier) @variable.builtin
 (#match? @variable.builtin "^(arguments|module|console|window|document)$")
 (#is-not? local))

((identifier) @function.builtin
 (#eq? @function.builtin "require")
 (#is-not? local))

; Literals
;---------

(this) @variable.builtin
(super) @variable.builtin

; Fallbacks — last so the specific rules above win (first-match-wins). Otherwise the
; catch-all @variable clobbers @constructor/@variable.builtin and @property clobbers
; @function.method, the way it did when these sat at the top.
(identifier) @variable
(property_identifier) @property
(private_property_identifier) @property ; `#count` field + `this.#count` access

[
  (true)
  (false)
  (null)
  (undefined)
] @constant.builtin

(comment) @comment

[
  (string)
  (template_string)
] @string

(regex) @string.special
(number) @number

; Tokens
;-------

[
  ";"
  (optional_chain)
  "."
  ","
] @punctuation.delimiter

[
  "-"
  "--"
  "-="
  "+"
  "++"
  "+="
  "*"
  "*="
  "**"
  "**="
  "/"
  "/="
  "%"
  "%="
  "<"
  "<="
  "<<"
  "<<="
  "="
  "=="
  "==="
  "!"
  "!="
  "!=="
  "=>"
  ">"
  ">="
  ">>"
  ">>="
  ">>>"
  ">>>="
  "~"
  "^"
  "&"
  "|"
  "^="
  "&="
  "|="
  "&&"
  "||"
  "??"
  "&&="
  "||="
  "??="
] @operator

[
  "("
  ")"
  "["
  "]"
  "{"
  "}"
]  @punctuation.bracket

(template_substitution
  "${" @punctuation.special
  "}" @punctuation.special) @embedded

[
  "as"
  "async"
  "await"
  "break"
  "case"
  "catch"
  "class"
  "const"
  "continue"
  "debugger"
  "default"
  "delete"
  "do"
  "else"
  "export"
  "extends"
  "finally"
  "for"
  "from"
  "function"
  "get"
  "if"
  "import"
  "in"
  "instanceof"
  "let"
  "new"
  "of"
  "return"
  "set"
  "static"
  "switch"
  "target"
  "throw"
  "try"
  "typeof"
  "var"
  "void"
  "while"
  "with"
  "yield"
] @keyword

; --- Glimmer additions ---
(glimmer_opening_tag) @tag.builtin
(glimmer_closing_tag) @tag.builtin
