; Code Editor: minimal JS injections. (The upstream nvim query also references
; `glimmer_template`, which only exists in the glimmer_javascript fork, so it can't
; compile against this grammar.)

; JSDoc annotations inside comments. Only `/**` block comments are JSDoc — not `//` line
; comments, plain `/* */`, or `/*** */` (per the JSDoc spec); the predicate gates on that.
((comment) @injection.content
 (#match? @injection.content "^/\\*\\*[^*]")
 (#set! injection.language "jsdoc"))

; Regex literals.
((regex_pattern) @injection.content
 (#set! injection.language "regex"))
