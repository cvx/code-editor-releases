[
	"FROM"
	"AS"
	"RUN"
	"CMD"
	"LABEL"
	"EXPOSE"
	"ENV"
	"ADD"
	"COPY"
	"ENTRYPOINT"
	"VOLUME"
	"USER"
	"WORKDIR"
	"ARG"
	"ONBUILD"
	"STOPSIGNAL"
	"HEALTHCHECK"
	"SHELL"
	"MAINTAINER"
	"CROSS_BUILD"
] @keyword

[
	":"
	"@"
] @operator

(comment) @comment


(image_spec
	(image_tag
		":" @punctuation.special)
	(image_digest
		"@" @punctuation.special))

; ENV / LABEL / ARG keys read as property names — placed before the string list
; so a quoted key (LABEL "k"="v") wins the same-span tie over @string.
(env_pair
	name: (_) @property)
(label_pair
	key: (_) @property)
(arg_instruction
	name: (_) @property)

; An unquoted ENV/LABEL/ARG value is still a string literal, just without quotes —
; color it like a quoted one. Field-scoped so image names / paths keep their default
; color; a nested `$VAR` expansion is a smaller span and paints on top.
(env_pair
	value: (unquoted_string) @string)
(label_pair
	value: (unquoted_string) @string)
(arg_instruction
	default: (unquoted_string) @string)

[
  (double_quoted_string)
  (single_quoted_string)
  (json_string)
] @string

(expansion
  [
	"$"
	"{"
	"}"
  ] @punctuation.special
) @none

((variable) @constant
 (#match? @constant "^[A-Z][A-Z_0-9]*$"))


