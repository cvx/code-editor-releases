; ERB: the code between `<% %>` is Ruby; the surrounding text is HTML.
; `injection.combined "true"` parses all fragments of each as one document, so an HTML element
; (or Ruby if/end) split across directives isn't orphaned. The explicit "true" is required —
; SwiftTreeSitter only surfaces `#set!` directives that carry a value.
((code) @injection.content
 (#set! injection.language "ruby")
 (#set! injection.combined "true"))

((content) @injection.content
 (#set! injection.language "html")
 (#set! injection.combined "true"))
