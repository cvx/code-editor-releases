(jsx_opening_element (identifier) @tag (#match? @tag "^[a-z][^.]*$"))
(jsx_closing_element (identifier) @tag (#match? @tag "^[a-z][^.]*$"))
(jsx_self_closing_element (identifier) @tag (#match? @tag "^[a-z][^.]*$"))

; Attribute names as variables, matching HTML/glimmer markup.
(jsx_attribute (property_identifier) @variable)
(jsx_opening_element (["<" ">"]) @punctuation.bracket)
(jsx_closing_element (["</" ">"]) @punctuation.bracket)
(jsx_self_closing_element (["<" "/>"]) @punctuation.bracket)

; `{ }` expression containers embed JS in JSX — the embedding-boundary accent.
(jsx_expression ["{" "}"] @punctuation.special)
