;; From nvim-treesitter/nvim-treesitter
[
  (code_span)
  (link_title)
] @text.literal

[
  (emphasis_delimiter)
  (code_span_delimiter)
] @punctuation.delimiter

(emphasis) @text.emphasis

(strong_emphasis) @text.strong

[
  (link_destination)
  (uri_autolink)
] @text.uri

(image_description) @text.reference

;; An inline link `[text](url)` is always a link, so color its text here. The
;; reference-style forms — `[text]`, `[text][]`, `[text][label]` — are only links
;; when a matching `[label]: url` definition exists, which the grammar can't
;; resolve (it optimistically parses every `[text]` as a `shortcut_link`). Those
;; are colored by `TreeSitterHighlighter.highlightMarkdownReferenceLinks`, a
;; post-pass that gates the color on the document's actual reference definitions.
(inline_link (link_text) @text.reference)

[
  (backslash_escape)
  (hard_line_break)
] @string.escape

(image ["!" "[" "]" "(" ")"] @punctuation.delimiter)
(inline_link ["[" "]" "(" ")"] @punctuation.delimiter)

; NOTE: extension not enabled by default
; (wiki_link ["[" "|" "]"] @punctuation.delimiter)
