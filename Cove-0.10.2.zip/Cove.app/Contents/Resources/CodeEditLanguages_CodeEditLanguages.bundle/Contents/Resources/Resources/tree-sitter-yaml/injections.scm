; Copyright 2025 nvim-treesitter
;
; Licensed under the Apache License, Version 2.0 (the "License");
; you may not use this file except in compliance with the License.
; You may obtain a copy of the License at
;
;     http://www.apache.org/licenses/LICENSE-2.0
;
; Unless required by applicable law or agreed to in writing, software
; distributed under the License is distributed on an "AS IS" BASIS,
; WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
; See the License for the specific language governing permissions and
; limitations under the License.


((comment) @injection.content
  (#set! injection.language "comment"))

; Github actions ("run") / Gitlab CI ("scripts")
; Taskfile scripts ("cmds", "cmd", "sh")
(block_mapping_pair
  key: (flow_node) @_run
  (#any-of? @_run "run" "script" "before_script" "after_script" "cmds" "cmd" "sh")
  value: (flow_node
    (plain_scalar
      (string_scalar) @injection.content)
    (#set! injection.language "bash")))

(block_mapping_pair
  key: (flow_node) @_run
  (#any-of? @_run "run" "script" "before_script" "after_script" "cmds" "cmd" "sh")
  value: (block_node
    (block_scalar) @injection.content
    (#set! injection.language "bash")
    (#offset! @injection.content 0 1 0 0)))

(block_mapping_pair
  key: (flow_node) @_run
  (#any-of? @_run "run" "script" "before_script" "after_script" "cmds" "sh")
  value: (block_node
    (block_sequence
      (block_sequence_item
        (flow_node
          (plain_scalar
            (string_scalar) @injection.content))
        (#set! injection.language "bash")))))

(block_mapping_pair
  key: (flow_node) @_run
  (#any-of? @_run "script" "before_script" "after_script" "cmds" "sh")
  value: (block_node
    (block_sequence
      (block_sequence_item
        (block_node
          (block_scalar) @injection.content
          (#set! injection.language "bash")
          (#offset! @injection.content 0 1 0 0))))))

; Prometheus Alertmanager ("expr")
(block_mapping_pair
  key: (flow_node) @_expr
  (#eq? @_expr "expr")
  value: (flow_node
    (plain_scalar
      (string_scalar) @injection.content)
    (#set! injection.language "promql")))

(block_mapping_pair
  key: (flow_node) @_expr
  (#eq? @_expr "expr")
  value: (block_node
    (block_scalar) @injection.content
    (#set! injection.language "promql")
    (#offset! @injection.content 0 1 0 0)))

(block_mapping_pair
  key: (flow_node) @_expr
  (#eq? @_expr "expr")
  value: (block_node
    (block_sequence
      (block_sequence_item
        (flow_node
          (plain_scalar
            (string_scalar) @injection.content))
        (#set! injection.language "promql")))))

(block_mapping_pair
  key: (flow_node) @_expr
  (#eq? @_expr "expr")
  value: (block_node
    (block_sequence
      (block_sequence_item
        (block_node
          (block_scalar) @injection.content
          (#set! injection.language "promql")
          (#offset! @injection.content 0 1 0 0))))))

; --- Code Editor additions. These overlap the generic `run:`/`script:` → bash patterns
;     above; `injection.priority` (read by TreeSitterHighlighter) makes the more specific
;     language win regardless of tree-sitter's match-emission order. ---

; GitHub Actions `if:` conditions are expressions (the `${{ }}` wrapper is optional), so
; highlight the whole value with JavaScript — block scalar (`if: |`) or inline.
(block_mapping_pair
  key: (flow_node) @_if
  (#eq? @_if "if")
  value: (block_node
    (block_scalar) @injection.content
    (#set! injection.language "javascript")
    (#set! injection.priority "100")))

(block_mapping_pair
  key: (flow_node) @_if
  (#eq? @_if "if")
  value: (flow_node
    (plain_scalar (string_scalar) @injection.content))
  (#set! injection.language "javascript")
  (#set! injection.priority "100"))

; actions/github-script & friends: `with: { script: | ... }` is JavaScript.
(block_mapping_pair
  key: (flow_node) @_with
  (#eq? @_with "with")
  value: (block_node
    (block_mapping
      (block_mapping_pair
        key: (flow_node) @_script
        (#eq? @_script "script")
        value: (block_node
          (block_scalar) @injection.content
          (#set! injection.language "javascript")
          (#set! injection.priority "100"))))))

; `run:` whose sibling `shell:` selects a non-bash interpreter (GitHub Actions custom shells).
; tree-sitter sibling patterns are order-sensitive, and `shell:` may sit before or after `run:`
; (e.g. `shell: ruby {0}` declared above the step's `run:`, often with `env:` in between), so each
; language needs both orderings or the override silently falls back to bash. Anchored to a
; `block_sequence_item` (a GH Actions step is always a `steps:` list entry) so the unanchored
; sibling-pair search — O(children²) per `block_mapping` — never runs over a large flat mapping
; (e.g. a lockfile's `dependencies:` block): that froze the app opening a 17k-line pnpm-lock.yaml.
(block_sequence_item
  (block_node
    (block_mapping
      (block_mapping_pair
        key: (flow_node) @_run
        (#eq? @_run "run")
        value: (block_node (block_scalar) @injection.content))
      (block_mapping_pair
        key: (flow_node) @_shell
        (#eq? @_shell "shell")
        value: (flow_node) @_shellval
        (#match? @_shellval "^ruby"))
      (#set! injection.language "ruby")
      (#set! injection.priority "100"))))

(block_sequence_item
  (block_node
    (block_mapping
      (block_mapping_pair
        key: (flow_node) @_shell
        (#eq? @_shell "shell")
        value: (flow_node) @_shellval
        (#match? @_shellval "^ruby"))
      (block_mapping_pair
        key: (flow_node) @_run
        (#eq? @_run "run")
        value: (block_node (block_scalar) @injection.content))
      (#set! injection.language "ruby")
      (#set! injection.priority "100"))))

(block_sequence_item
  (block_node
    (block_mapping
      (block_mapping_pair
        key: (flow_node) @_run
        (#eq? @_run "run")
        value: (block_node (block_scalar) @injection.content))
      (block_mapping_pair
        key: (flow_node) @_shell
        (#eq? @_shell "shell")
        value: (flow_node) @_shellval
        (#match? @_shellval "^(node|javascript|deno)"))
      (#set! injection.language "javascript")
      (#set! injection.priority "100"))))

(block_sequence_item
  (block_node
    (block_mapping
      (block_mapping_pair
        key: (flow_node) @_shell
        (#eq? @_shell "shell")
        value: (flow_node) @_shellval
        (#match? @_shellval "^(node|javascript|deno)"))
      (block_mapping_pair
        key: (flow_node) @_run
        (#eq? @_run "run")
        value: (block_node (block_scalar) @injection.content))
      (#set! injection.language "javascript")
      (#set! injection.priority "100"))))
