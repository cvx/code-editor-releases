(comment) @comment
(negation) @keyword
[
  (wildcard_chars)
  (wildcard_chars_allow_slash)
  (wildcard_char_single)
] @operator
(directory_separator) @punctuation.delimiter
