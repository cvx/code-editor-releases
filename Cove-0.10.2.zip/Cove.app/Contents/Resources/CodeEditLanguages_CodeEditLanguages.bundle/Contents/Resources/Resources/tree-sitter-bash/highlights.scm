[
  (string)
  (raw_string)
  (heredoc_body)
] @string

; Heredoc opener `<<EOF` — embedding-boundary accent.
(heredoc_start) @punctuation.special

; String interpolation — the expansion delimiters INSIDE a string are the embedding accent, like JS
; `${ }` / ruby `#{ }`. Only in strings: a bare `$x`/`$(…)` in command position stays neutral (these
; rules precede the generic `"$"` @operator below, so they win first-match-wins). `variable_name`
; inside still resolves to @variable; command-substitution contents still highlight as commands.
(string (simple_expansion "$" @punctuation.special))
(string (expansion ["${" "}"] @punctuation.special))
(string (command_substitution ["$(" ")"] @punctuation.special))

(command_name) @function

(variable_name) @variable ; plain variable, like JS (was @property)

[
  "case"
  "do"
  "done"
  "elif"
  "else"
  "esac"
  "export"
  "fi"
  "for"
  "function"
  "if"
  "in"
  "select"
  "then"
  "unset"
  "until"
  "while"
] @keyword

(comment) @comment

(function_definition name: (word) @function)

(file_descriptor) @number

[
  (command_substitution)
  (process_substitution)
  (expansion)
]@embedded

[
  "$"
  "&&"
  ">"
  ">>"
  "<"
  "|"
] @operator

(
  (command (_) @constant)
  (#match? @constant "^-")
)
