; Code Editor: TypeScript injections, mirroring the JS query. The upstream nvim file is just
; `inherits: ecma`, a directive our loader doesn't process — so without this, `.ts`/`.tsx`
; injected nothing (no JSDoc, no regex) unlike `.js`.

; JSDoc annotations inside comments. Only `/**` block comments are JSDoc — not `//` line
; comments, plain `/* */`, or `/*** */` (per the JSDoc spec); the predicate gates on that.
((comment) @injection.content
 (#match? @injection.content "^/\\*\\*[^*]")
 (#set! injection.language "jsdoc"))

; Regex literals.
((regex_pattern) @injection.content
 (#set! injection.language "regex"))
