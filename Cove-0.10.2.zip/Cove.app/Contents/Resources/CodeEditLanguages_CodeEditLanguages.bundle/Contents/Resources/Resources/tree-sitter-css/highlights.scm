(comment) @comment

; Selectors (element / nesting / universal) → @keyword, distinct from the @property color used for
; property names — a selector and a declaration property were otherwise the same hue.
(tag_name) @keyword
(nesting_selector) @keyword
(universal_selector) @keyword

"~" @operator
">" @operator
"+" @operator
"-" @operator
"*" @operator
"/" @operator
"=" @operator
"^=" @operator
"|=" @operator
"~=" @operator
"$=" @operator
"*=" @operator

"and" @operator
"or" @operator
"not" @operator
"only" @operator

(attribute_selector (plain_value) @string)
(pseudo_element_selector (tag_name) @keyword)
(pseudo_class_selector (class_name) @keyword)

; Class / id / namespace selectors → @keyword too, so the whole selector family reads as one color,
; distinct from property names.
(class_name) @keyword
(id_name) @keyword
(namespace_name) @keyword
; Custom properties (`--main`) → @type (a distinct hue), in both their declaration and `var(--main)`
; uses — BEFORE the generic property_name→@property and plain_value→@constant rules so they win
; (first-match-wins). Keeps a custom property visible instead of the plain body-text @variable color.
((property_name) @type
 (#match? @type "^--"))
((plain_value) @type
 (#match? @type "^--"))
(property_name) @property
(feature_name) @property
; Value keywords (`bold`, `none`, `uppercase`, font names, …) → @constant, so a declaration value
; isn't left at the plain/punctuation color. More specific plain_value rules above still win.
(plain_value) @constant

(attribute_name) @attribute

(function_name) @function

"@media" @keyword
"@import" @keyword
"@charset" @keyword
"@namespace" @keyword
"@supports" @keyword
"@keyframes" @keyword
(at_keyword) @keyword
(to) @keyword
(from) @keyword
(important) @keyword

(string_value) @string
(color_value) @string.special

(integer_value) @number
(float_value) @number
(unit) @type

"#" @punctuation.delimiter
"," @punctuation.delimiter
":" @punctuation.delimiter
