(tag_name) @keyword
(type) @type

; Parameter / property names (e.g. `@param {string} foo`).
(identifier) @variable.parameter
