(comment) @comment
; SCSS `//` line comments are a distinct node from `/* */` (comment) — capture both.
(single_line_comment) @comment

; Selectors (element / nesting / universal) → @keyword, distinct from the @property color used for
; property names — a selector and a declaration property were otherwise the same hue.
(tag_name) @keyword
(nesting_selector) @keyword
(universal_selector) @keyword

"~" @operator
">" @operator
"+" @operator
"-" @operator
"*" @operator
"/" @operator
"=" @operator
"^=" @operator
"|=" @operator
"~=" @operator
"$=" @operator
"*=" @operator

"and" @operator
"or" @operator
"not" @operator
"only" @operator

(attribute_selector (plain_value) @string)
(pseudo_element_selector (tag_name) @keyword)
(pseudo_class_selector (class_name) @keyword)

; Class / id / namespace selectors → @keyword too, so the whole selector family reads as one color,
; distinct from property names.
(class_name) @keyword
(id_name) @keyword
(namespace_name) @keyword
; Custom properties (`--main`) → @type (declaration + `var(--main)` use) — before the generic
; property_name→@property and plain_value→@constant rules so they win, like the css query.
((property_name) @type
 (#match? @type "^--"))
((plain_value) @type
 (#match? @type "^--"))
(property_name) @property
(feature_name) @property
; Value keywords (`bold`, `none`, `uppercase`, font names, …) → @constant, so a declaration value
; isn't left at the plain/punctuation color. More specific plain_value rules above still win.
(plain_value) @constant

(attribute_name) @attribute

(function_name) @function

; Mixin/function definition names + `@include` call target → @function, matching their call sites
; (`dbl(2)` is already a function_name). Placeholder selectors `%ph` → @property, like class selectors.
(mixin_statement (name) @function)
(function_statement (name) @function)
(include_statement (identifier) @function)
; Placeholder selectors `%ph` are selectors → @keyword, with the rest of the selector family.
(placeholder (name) @keyword)

; SCSS variables — `$primary:` (definition) and its `$primary` uses (reference) → @type, a distinct
; hue so a variable stands out from plain body text. Interpolation `#{ }` is accented separately by
; scan (the grammar buries it in plain_value).
(variable_name) @type
(variable_value) @type

"@media" @keyword
"@import" @keyword
"@charset" @keyword
"@namespace" @keyword
"@supports" @keyword
"@keyframes" @keyword
; SCSS control-flow / mixin / module at-rules — these parse as their own node types (not the generic
; (at_keyword), and aren't in the list above), so they rendered uncolored. Color them like keywords.
; (`@content` is omitted — the vendored grammar has no token for it; adding it fails to compile.)
"@mixin" @keyword
"@include" @keyword
"@function" @keyword
"@return" @keyword
"@if" @keyword
"@else" @keyword
"@each" @keyword
"@for" @keyword
"@while" @keyword
"@extend" @keyword
"@use" @keyword
"@forward" @keyword
"@at-root" @keyword
"@debug" @keyword
"@warn" @keyword
"@error" @keyword
"@apply" @keyword
(at_keyword) @keyword
(to) @keyword
(from) @keyword
(important) @keyword

(string_value) @string
(color_value) @string.special

(integer_value) @number
(float_value) @number
(unit) @type

"#" @punctuation.delimiter
"," @punctuation.delimiter
