#!/bin/sh
# Cove CLI: what the installed `cove` command runs (`CLIInstaller.shim`, a trampoline that execs this
# script out of the app bundle, so it updates with the app). Usage: cove [-w|--wait] [path ...]
#
# The trampoline's contract, kept stable across versions: `COVE_BUNDLE_ID` names the app to open
# paths in, and the arguments are the user's. The app's side is the `cove://trust` and `cove://wait`
# URLs below (`CLITrust`, `CLIWait`), which it keeps accepting as they are.
#
# Sparkle replaces the bundle whole, so a `cove -w` still reading the old copy keeps its inode. Never
# edit an installed copy of this file in place: `sh` reads a script as it runs it.
BUNDLE_ID="${COVE_BUNDLE_ID:?run by the installed cove command}"
SCHEME="cove"
# The app only accepts temp files from its own temp dir or /tmp, whatever $TMPDIR says.
tmp="$(getconf DARWIN_USER_TEMP_DIR 2>/dev/null)"
[ -d "$tmp" ] || tmp=/tmp
tmp="${tmp%/}"

# Split the wait flag out; rebuild "$@" with just the paths.
wait=0
count=$#
while [ "$count" -gt 0 ]; do
  arg="$1"; shift; count=$((count - 1))
  case "$arg" in
    -w|--wait) wait=1 ;;
    *) set -- "$@" "$arg" ;;
  esac
done

# A bare `cove` (or just `-w`) opens the current directory as a workspace.
[ $# -eq 0 ] && set -- "$(pwd)"

b64() { printf '%s' "$1" | base64 | tr -d '\n' | tr '+/' '-_' | tr -d '='; }
abspath() { case "$1" in /*) printf '%s' "$1" ;; *) printf '%s/%s' "$(pwd)" "$1" ;; esac; }

# Folders open trusted, so they may run their own language servers and formatters: one named from a
# shell is the user's choice. Any page can open a cove:// URL, so the app also wants a token file
# listing them, which only a local process can write. A folder has no tab to wait on, so it never
# takes the wait path; the files stay in "$@". A file that doesn't exist yet opens empty and is
# created by its first save. `open` refuses it, so without -w it rides the token too. One whose
# folder isn't there or isn't writable is skipped, so -w never waits on a tab that can't open.
token=""
url=""
failed=0
count=$#
while [ "$count" -gt 0 ]; do
  arg="$1"; shift; count=$((count - 1))
  if [ ! -e "$arg" ] && [ ! -w "$(dirname -- "$arg")/." ]; then
    printf 'cove: can’t create %s\n' "$arg" >&2
    failed=1
  elif [ -d "$arg" ] || { [ ! -e "$arg" ] && [ "$wait" -ne 1 ]; }; then
    if [ -z "$token" ]; then
      token="$(mktemp "$tmp/cove-trust.XXXXXX")" || exit 1
      url="$SCHEME://trust?t=$(b64 "$token")"
    fi
    abs="$(abspath "$arg")"
    printf '%s\n' "$abs" >> "$token"
    url="$url&f=$(b64 "$abs")"
  else
    set -- "$@" "$arg"
  fi
done
if [ -n "$token" ]; then
  open -b "$BUNDLE_ID" "$url" || { rm -f "$token"; exit 1; }
fi
[ $# -eq 0 ] && exit "$failed"

# No wait: hand off to `open` and return.
if [ "$wait" -ne 1 ]; then
  exec open -b "$BUNDLE_ID" "$@"
fi

sentinel="$(mktemp "$tmp/cove-wait.XXXXXX")" || exit 1
trap 'rm -f "$sentinel"' EXIT INT TERM
url="$SCHEME://wait?s=$(b64 "$sentinel")"
for f in "$@"; do
  url="$url&f=$(b64 "$(abspath "$f")")"
done
open -b "$BUNDLE_ID" "$url" || exit 1
# Block until the app deletes the sentinel (all tracked tabs closed / app quit). The app writes
# its pid in once it takes the wait; a crash leaves the sentinel, so stop when that pid is gone.
while [ -e "$sentinel" ]; do
  pid=""; read -r pid < "$sentinel" 2>/dev/null
  if [ -n "$pid" ] && ! kill -0 "$pid" 2>/dev/null; then exit 1; fi
  sleep 0.15
done
