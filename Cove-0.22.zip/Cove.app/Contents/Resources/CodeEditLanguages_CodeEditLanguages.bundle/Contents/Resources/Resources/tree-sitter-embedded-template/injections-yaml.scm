; ERB whose text is YAML (`database.yml`, `*.yml.erb`): the code between `<% %>` is Ruby, the text around it YAML.
; Combined, as in `injections.scm`: the YAML parses as one document with the directives cut out, so a key whose
; value is `<%= … %>` reads as a key with no value, and the keys around it keep their structure.
((code) @injection.content
 (#set! injection.language "ruby")
 (#set! injection.combined "true"))

((content) @injection.content
 (#set! injection.language "yaml")
 (#set! injection.combined "true"))
