; Mapping keys come FIRST: the highlighter resolves first-match-wins, and a key is also a
; (string_scalar), so the key → @tag rules must precede the generic @string rule below or
; keys would render in the string color (indistinguishable from their values).
(block_mapping_pair
  key: (flow_node
    [
      (double_quote_scalar)
      (single_quote_scalar)
    ] @tag))

(block_mapping_pair
  key: (flow_node
    (plain_scalar
      (string_scalar) @tag)))

(flow_mapping
  (_
    key: (flow_node
      [
        (double_quote_scalar)
        (single_quote_scalar)
      ] @tag)))

(flow_mapping
  (_
    key: (flow_node
      (plain_scalar
        (string_scalar) @tag))))

(boolean_scalar) @boolean

(null_scalar) @constant.builtin

; A bare scalar stays the body ink: only what is quoted (or a block) reads as a string.
[
  (double_quote_scalar)
  (single_quote_scalar)
  (block_scalar)
] @string

[
  (integer_scalar)
  (float_scalar)
] @number

(comment) @comment

[
  (anchor_name)
  (alias_name)
] @label

(tag) @type

[
  (yaml_directive)
  (tag_directive)
  (reserved_directive)
] @attribute

[
  ","
  "-"
  ":"
  "?"
] @punctuation.delimiter

; Block-scalar indicators introduce embedded literal content (e.g. injected `run:` bash) —
; the embedding-boundary accent.
[
  ">"
  "|"
] @punctuation.special

[
  "["
  "]"
  "{"
  "}"
] @punctuation.bracket

; Anchors/aliases/doc markers — neutral punctuation, not the interpolation accent (which
; `@punctuation.special` now carries) since they aren't embedding boundaries.
[
  "*"
  "&"
  "---"
  "..."
] @punctuation.delimiter
